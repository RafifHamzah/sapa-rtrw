@props(['desa' => null])

{{--
    Sub-navigasi modul Desa. Menu ditampilkan BERDASARKAN PERMISSION user pada
    desa terkait (via DesaPolicy): semua anggota lihat "Daftar Anggota";
    Admin/Staff lihat "Permintaan Bergabung"; hanya Admin lihat "Pengaturan Desa".
--}}
@php
    $user = auth()->user();
    $tabs = [
        ['label' => 'Desa Saya', 'route' => 'desa.index', 'params' => [], 'icon' => 'home', 'show' => true],
    ];
    if ($desa) {
        $tabs[] = ['label' => 'Daftar Anggota', 'route' => 'desa.members', 'params' => ['desa' => $desa], 'icon' => 'users', 'show' => $user->can('view', $desa)];
        $tabs[] = ['label' => 'Kas', 'route' => 'desa.kas', 'params' => ['desa' => $desa], 'icon' => 'wallet', 'show' => $user->can('view', $desa)];
        $tabs[] = ['label' => 'Iuran', 'route' => 'desa.iuran', 'params' => ['desa' => $desa], 'icon' => 'receipt', 'show' => $user->can('view', $desa)];
        $tabs[] = ['label' => 'Permintaan Bergabung', 'route' => 'desa.requests', 'params' => ['desa' => $desa], 'icon' => 'inbox', 'show' => $user->can('reviewRequests', $desa)];
        $tabs[] = ['label' => 'Pengaturan Desa', 'route' => 'desa.settings', 'params' => ['desa' => $desa], 'icon' => 'adjust', 'show' => $user->can('update', $desa)];
    }
@endphp

<div class="flex flex-wrap gap-1 rounded-2xl bg-slate-100 p-1">
    @foreach ($tabs as $t)
        @continue(! $t['show'])
        <a href="{{ route($t['route'], $t['params']) }}"
           @class([
               'inline-flex items-center gap-2 rounded-xl px-3.5 py-2 text-sm font-semibold transition-colors',
               'bg-white text-brand-700 shadow-sm' => request()->routeIs($t['route']),
               'text-slate-500 hover:text-slate-800' => ! request()->routeIs($t['route']),
           ])>
            <x-ui.icon :name="$t['icon']" class="w-4 h-4" />
            {{ $t['label'] }}
        </a>
    @endforeach
</div>
