@php
    $months = [1 => 'Januari', 2 => 'Februari', 3 => 'Maret', 4 => 'April', 5 => 'Mei', 6 => 'Juni', 7 => 'Juli', 8 => 'Agustus', 9 => 'September', 10 => 'Oktober', 11 => 'November', 12 => 'Desember'];
@endphp

<x-app-layout>
    <x-slot name="header">
        <div class="flex items-center gap-3">
            <span class="w-11 h-11 rounded-2xl bg-brand-600 text-white flex items-center justify-center"><x-ui.icon name="receipt" class="w-6 h-6" /></span>
            <div>
                <h1 class="text-xl font-bold text-slate-900">Iuran Desa</h1>
                <p class="text-sm text-slate-500">{{ $desa->name }}</p>
            </div>
        </div>
    </x-slot>

    <x-desa-tabs :desa="$desa" />

    <div class="mt-6 space-y-6">
        {{-- ===== Tagihan saya ===== --}}
        <div>
            <h3 class="text-sm font-semibold text-slate-500 mb-2">Tagihan saya</h3>
            @if ($myDues->isEmpty())
                <x-ui.card>
                    <x-ui.empty-state icon="receipt" title="Belum ada tagihan"
                        message="Tagihan iuran desa untuk Anda akan muncul di sini." />
                </x-ui.card>
            @else
                <div class="space-y-3">
                    @foreach ($myDues as $d)
                        <x-ui.card padding="p-4" class="flex flex-col sm:flex-row sm:items-center gap-4">
                            <div class="flex items-center gap-4 min-w-0 flex-1">
                                <span @class([
                                    'w-12 h-12 rounded-2xl flex items-center justify-center shrink-0',
                                    'bg-emerald-50 text-emerald-600' => $d->isPaid(),
                                    'bg-amber-50 text-amber-600' => ! $d->isPaid(),
                                ])>
                                    <x-ui.icon name="receipt" class="w-6 h-6" />
                                </span>
                                <div class="min-w-0">
                                    <p class="font-semibold text-slate-800">Iuran {{ $d->periodLabel() }}</p>
                                    <p class="text-sm text-slate-500">{{ rupiah($d->amount) }}
                                        @if ($d->due_date) · jatuh tempo {{ $d->due_date->translatedFormat('d M Y') }} @endif
                                    </p>
                                </div>
                            </div>
                            <div class="flex items-center justify-between sm:justify-end gap-2 shrink-0">
                                <x-status-badge :status="$d->status" />
                                @if (! $d->isPaid())
                                    @if ($d->midtrans_order_id)
                                        <form method="POST" action="{{ route('desa.iuran.sync', [$desa, $d]) }}">@csrf
                                            <button type="submit" class="rounded-xl px-3 py-2 text-sm font-semibold text-brand-700 ring-1 ring-brand-200 hover:bg-brand-50">Cek status</button>
                                        </form>
                                    @endif
                                    <button type="button"
                                            onclick="bayarDesa('{{ route('desa.iuran.pay', [$desa, $d]) }}', '{{ route('desa.iuran.sync', [$desa, $d]) }}')"
                                            class="inline-flex items-center gap-2 rounded-xl bg-brand-600 px-4 py-2 text-sm font-semibold text-white hover:bg-brand-700">
                                        Bayar
                                    </button>
                                @endif
                            </div>
                        </x-ui.card>
                    @endforeach
                </div>
            @endif
        </div>

        {{-- ===== Panel kelola (Admin/Staff) ===== --}}
        @if ($canManage)
            <x-ui.card>
                <h3 class="font-bold text-slate-900">Buat tagihan untuk semua anggota</h3>
                <p class="text-sm text-slate-500 mt-0.5">Generate tagihan satu periode untuk seluruh anggota (yang sudah ada dilewati).</p>
                <form method="POST" action="{{ route('desa.iuran.generate', $desa) }}" class="mt-4 grid sm:grid-cols-2 lg:grid-cols-4 gap-3">
                    @csrf
                    <input name="amount" type="number" min="1" placeholder="Nominal (Rp)" class="field-input" required>
                    <select name="period_month" class="field-input" required>
                        @foreach ($months as $num => $label)
                            <option value="{{ $num }}" @selected($num == now()->month)>{{ $label }}</option>
                        @endforeach
                    </select>
                    <input name="period_year" type="number" min="2020" max="2100" value="{{ now()->year }}" class="field-input" required>
                    <input name="due_date" type="date" class="field-input" placeholder="Jatuh tempo">
                    <x-ui.button type="submit" class="sm:col-span-2 lg:col-span-4 justify-self-start">Generate Tagihan</x-ui.button>
                </form>
                <x-input-error :messages="$errors->get('amount')" class="mt-2" />
            </x-ui.card>

            <div>
                <h3 class="text-sm font-semibold text-slate-500 mb-2">Semua tagihan desa</h3>
                @if ($allDues->isEmpty())
                    <x-ui.card>
                        <x-ui.empty-state icon="receipt" title="Belum ada tagihan"
                            message="Buat tagihan lewat form di atas." />
                    </x-ui.card>
                @else
                    <x-ui.card padding="p-2 sm:p-3">
                        <div class="divide-y divide-slate-100">
                            @foreach ($allDues as $d)
                                <div class="flex items-center gap-3 p-3">
                                    <span class="w-10 h-10 rounded-xl bg-slate-100 text-slate-500 flex items-center justify-center font-semibold shrink-0">
                                        {{ strtoupper(substr($d->user->name ?? '?', 0, 1)) }}
                                    </span>
                                    <div class="min-w-0 flex-1">
                                        <p class="font-semibold text-slate-800 truncate">{{ $d->user->name ?? '—' }}</p>
                                        <p class="text-xs text-slate-500">{{ $d->periodLabel() }} · {{ rupiah($d->amount) }}</p>
                                    </div>
                                    <x-status-badge :status="$d->status" />
                                    @if (! $d->isPaid())
                                        <form method="POST" action="{{ route('desa.iuran.markPaid', [$desa, $d]) }}">@csrf
                                            <button type="submit" class="inline-flex items-center gap-1.5 rounded-xl px-3 py-2 text-sm font-semibold text-emerald-700 ring-1 ring-emerald-200 hover:bg-emerald-50">
                                                <x-ui.icon name="check" class="w-4 h-4" /> Tandai Lunas
                                            </button>
                                        </form>
                                    @endif
                                </div>
                            @endforeach
                        </div>
                    </x-ui.card>
                @endif
            </div>
        @endif
    </div>

    @push('scripts')
        <script src="https://app.sandbox.midtrans.com/snap/snap.js"
                data-client-key="{{ config('services.midtrans.client_key') }}"></script>
        <script>
            async function bayarDesa(payUrl, syncUrl) {
                const csrf = document.querySelector('meta[name=csrf-token]')?.content;
                let data;
                try {
                    const res = await fetch(payUrl, { method: 'POST', headers: { 'X-CSRF-TOKEN': csrf, 'Accept': 'application/json' } });
                    data = await res.json();
                } catch (e) {
                    window.toast && window.toast('Gagal memulai pembayaran.', 'error');
                    return;
                }
                if (!data.snap_token || typeof window.snap === 'undefined') {
                    window.toast && window.toast(data.message || 'Pembayaran online belum tersedia.', 'error');
                    return;
                }
                // Auto-sync setelah bayar (webhook tak sampai localhost).
                const finalize = () => fetch(syncUrl, { method: 'POST', headers: { 'X-CSRF-TOKEN': csrf } }).then(() => window.location.reload());
                window.snap.pay(data.snap_token, {
                    onSuccess: finalize,
                    onPending: finalize,
                    onError: () => window.toast && window.toast('Pembayaran gagal. Coba lagi.', 'error'),
                    onClose: () => {},
                });
            }
        </script>
    @endpush
</x-app-layout>
