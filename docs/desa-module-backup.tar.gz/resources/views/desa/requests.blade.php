<x-app-layout>
    <x-slot name="header">
        <div class="flex items-center gap-3">
            <span class="w-11 h-11 rounded-2xl bg-brand-600 text-white flex items-center justify-center"><x-ui.icon name="inbox" class="w-6 h-6" /></span>
            <div>
                <h1 class="text-xl font-bold text-slate-900">Permintaan Bergabung</h1>
                <p class="text-sm text-slate-500">{{ $desa->name }}</p>
            </div>
        </div>
    </x-slot>

    <x-desa-tabs :desa="$desa" />

    <div class="mt-6">
        @if ($requests->isEmpty())
            <x-ui.card>
                <x-ui.empty-state icon="inbox" title="Belum ada permintaan"
                    message="Permintaan bergabung dari warga akan muncul di sini." />
            </x-ui.card>
        @else
            <x-ui.card padding="p-2 sm:p-3">
                <div class="divide-y divide-slate-100">
                    @foreach ($requests as $req)
                        <div class="flex items-center gap-3 p-3">
                            <span class="w-10 h-10 rounded-xl bg-slate-100 text-slate-500 flex items-center justify-center font-semibold shrink-0">
                                {{ strtoupper(substr($req->user->name, 0, 1)) }}
                            </span>
                            <div class="min-w-0 flex-1">
                                <p class="font-semibold text-slate-800 truncate">{{ $req->user->name }}</p>
                                <p class="text-xs text-slate-500 truncate">{{ $req->user->email }}</p>
                            </div>

                            @if ($req->status === \App\Enums\DesaJoinStatus::Pending)
                                <div class="flex items-center gap-2">
                                    <form method="POST" action="{{ route('desa.requests.approve', [$desa, $req]) }}">
                                        @csrf
                                        <button type="submit" class="inline-flex items-center gap-1.5 rounded-xl bg-brand-600 px-3 py-2 text-sm font-semibold text-white hover:bg-brand-700">
                                            <x-ui.icon name="check" class="w-4 h-4" /> Terima
                                        </button>
                                    </form>
                                    <form method="POST" action="{{ route('desa.requests.reject', [$desa, $req]) }}">
                                        @csrf
                                        <button type="submit" class="inline-flex items-center gap-1.5 rounded-xl px-3 py-2 text-sm font-semibold text-red-600 ring-1 ring-red-200 hover:bg-red-50">
                                            <x-ui.icon name="x" class="w-4 h-4" /> Tolak
                                        </button>
                                    </form>
                                </div>
                            @else
                                <x-status-badge :status="$req->status" />
                            @endif
                        </div>
                    @endforeach
                </div>
            </x-ui.card>
        @endif
    </div>
</x-app-layout>
