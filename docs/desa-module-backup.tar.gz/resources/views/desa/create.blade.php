<x-app-layout>
    <x-slot name="header">
        <div class="flex items-center gap-3">
            <a href="{{ route('desa.index') }}" class="w-10 h-10 rounded-xl ring-1 ring-slate-200 text-slate-500 flex items-center justify-center hover:bg-slate-100"><x-ui.icon name="arrow-left" class="w-5 h-5" /></a>
            <div>
                <h1 class="text-xl font-bold text-slate-900">Buat Desa</h1>
                <p class="text-sm text-slate-500">Isi informasi desa. Anda otomatis menjadi Admin.</p>
            </div>
        </div>
    </x-slot>

    <div class="max-w-2xl">
        <x-ui.card>
            <form method="POST" action="{{ route('desa.store') }}" class="space-y-4">
                @csrf

                <div>
                    <label for="name" class="block text-sm font-medium text-slate-700 mb-1">Nama Desa <span class="text-red-500">*</span></label>
                    <input id="name" name="name" value="{{ old('name') }}" class="field-input" required autofocus maxlength="255" placeholder="mis. Desa Sukamaju">
                    <x-input-error :messages="$errors->get('name')" class="mt-1" />
                </div>

                <div>
                    <label for="region" class="block text-sm font-medium text-slate-700 mb-1">Wilayah</label>
                    <input id="region" name="region" value="{{ old('region') }}" class="field-input" maxlength="255" placeholder="mis. Kec. Melati, Kab. Sukamaju">
                    <x-input-error :messages="$errors->get('region')" class="mt-1" />
                </div>

                <div>
                    <label for="address" class="block text-sm font-medium text-slate-700 mb-1">Alamat</label>
                    <input id="address" name="address" value="{{ old('address') }}" class="field-input" maxlength="255" placeholder="Alamat sekretariat / balai desa">
                    <x-input-error :messages="$errors->get('address')" class="mt-1" />
                </div>

                <div>
                    <label for="description" class="block text-sm font-medium text-slate-700 mb-1">Deskripsi</label>
                    <textarea id="description" name="description" rows="3" class="field-input" maxlength="2000" placeholder="Ceritakan singkat tentang desa Anda">{{ old('description') }}</textarea>
                    <x-input-error :messages="$errors->get('description')" class="mt-1" />
                </div>

                <div class="flex items-center gap-3 pt-2">
                    <x-ui.button type="submit" size="lg">Buat Desa</x-ui.button>
                    <a href="{{ route('desa.index') }}" class="text-sm font-medium text-slate-500 hover:text-slate-700">Batal</a>
                </div>
            </form>
        </x-ui.card>
    </div>
</x-app-layout>
