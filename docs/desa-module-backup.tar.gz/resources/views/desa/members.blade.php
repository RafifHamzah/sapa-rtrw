<x-app-layout>
    <x-slot name="header">
        <div class="flex items-center gap-3">
            <span class="w-11 h-11 rounded-2xl bg-brand-600 text-white flex items-center justify-center"><x-ui.icon name="users" class="w-6 h-6" /></span>
            <div>
                <h1 class="text-xl font-bold text-slate-900">Daftar Anggota</h1>
                <p class="text-sm text-slate-500">{{ $desa->name }} · {{ $members->count() }} anggota</p>
            </div>
        </div>
    </x-slot>

    <x-desa-tabs :desa="$desa" />

    <div class="mt-6">
        <x-input-error :messages="$errors->get('role')" class="mb-3" />

        <x-ui.card padding="p-2 sm:p-3">
            <div class="divide-y divide-slate-100">
                @foreach ($members as $member)
                    <div class="flex items-center gap-3 p-3">
                        <span class="w-10 h-10 rounded-xl bg-brand-600 text-white flex items-center justify-center font-semibold shrink-0">
                            {{ strtoupper(substr($member->user->name, 0, 1)) }}
                        </span>
                        <div class="min-w-0 flex-1">
                            <p class="font-semibold text-slate-800 truncate">
                                {{ $member->user->name }}
                                @if ($member->user_id === auth()->id())<span class="text-xs font-normal text-slate-400">(Anda)</span>@endif
                            </p>
                            <p class="text-xs text-slate-500 truncate">{{ $member->user->email }}</p>
                        </div>

                        @if ($canManageRoles)
                            <form method="POST" action="{{ route('desa.members.role', [$desa, $member]) }}">
                                @csrf
                                @method('PATCH')
                                <select name="role" onchange="this.form.submit()"
                                        class="rounded-xl border-slate-300 text-sm font-medium text-slate-700 focus:border-brand-500 focus:ring-brand-500 py-1.5 pl-3 pr-8">
                                    @foreach (\App\Enums\DesaRole::options() as $value => $label)
                                        <option value="{{ $value }}" @selected($member->role->value === $value)>{{ $label }}</option>
                                    @endforeach
                                </select>
                            </form>
                        @else
                            <x-status-badge :status="$member->role" />
                        @endif
                    </div>
                @endforeach
            </div>
        </x-ui.card>

        @if ($canManageRoles)
            <p class="mt-3 text-xs text-slate-400">Ubah role langsung dari daftar. Admin terakhir tidak dapat diturunkan.</p>
        @endif
    </div>
</x-app-layout>
