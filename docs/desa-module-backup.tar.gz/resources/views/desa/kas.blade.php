<x-app-layout>
    <x-slot name="header">
        <div class="flex items-center gap-3">
            <span class="w-11 h-11 rounded-2xl bg-brand-600 text-white flex items-center justify-center"><x-ui.icon name="wallet" class="w-6 h-6" /></span>
            <div>
                <h1 class="text-xl font-bold text-slate-900">Kas Desa</h1>
                <p class="text-sm text-slate-500">{{ $desa->name }} · transparan untuk semua anggota</p>
            </div>
        </div>
    </x-slot>

    <x-desa-tabs :desa="$desa" />

    <div class="mt-6 space-y-6">
        {{-- Ringkasan saldo --}}
        <div class="grid sm:grid-cols-3 gap-4">
            <x-ui.card>
                <p class="text-sm text-slate-500">Saldo Kas</p>
                <p class="mt-1 text-2xl font-extrabold text-slate-900">{{ rupiah($balance) }}</p>
            </x-ui.card>
            <x-ui.card>
                <p class="text-sm text-slate-500">Total Pemasukan</p>
                <p class="mt-1 text-2xl font-extrabold text-emerald-600">{{ rupiah($income) }}</p>
            </x-ui.card>
            <x-ui.card>
                <p class="text-sm text-slate-500">Total Pengeluaran</p>
                <p class="mt-1 text-2xl font-extrabold text-red-500">{{ rupiah($expense) }}</p>
            </x-ui.card>
        </div>

        {{-- Catat transaksi (Admin/Staff) --}}
        @if ($canManage)
            <x-ui.card>
                <h3 class="font-bold text-slate-900">Catat Transaksi</h3>
                <form method="POST" action="{{ route('desa.kas.store', $desa) }}" class="mt-4 grid sm:grid-cols-2 lg:grid-cols-4 gap-3">
                    @csrf
                    <select name="type" class="field-input" required>
                        <option value="income">Pemasukan</option>
                        <option value="expense">Pengeluaran</option>
                    </select>
                    <input name="amount" type="number" min="1" placeholder="Nominal (Rp)" class="field-input" required>
                    <input name="description" type="text" maxlength="255" placeholder="Keterangan" class="field-input sm:col-span-2 lg:col-span-1" required>
                    <input name="transaction_date" type="date" value="{{ now()->toDateString() }}" class="field-input" required>
                    <x-ui.button type="submit" class="lg:col-span-4 sm:col-span-2 justify-self-start">Simpan Transaksi</x-ui.button>
                </form>
                <x-input-error :messages="$errors->get('amount')" class="mt-2" />
            </x-ui.card>
        @endif

        {{-- Riwayat --}}
        <div>
            <h3 class="text-sm font-semibold text-slate-500 mb-2">Riwayat Transaksi</h3>
            @if ($transactions->isEmpty())
                <x-ui.card>
                    <x-ui.empty-state icon="wallet" title="Belum ada transaksi"
                        message="Catatan pemasukan & pengeluaran kas desa akan muncul di sini." />
                </x-ui.card>
            @else
                <x-ui.card padding="p-2 sm:p-3">
                    <div class="divide-y divide-slate-100">
                        @foreach ($transactions as $trx)
                            <div class="flex items-center gap-3 p-3">
                                <span @class([
                                    'w-10 h-10 rounded-xl flex items-center justify-center shrink-0',
                                    'bg-emerald-50 text-emerald-600' => $trx->type === \App\Enums\DesaTransactionType::Income,
                                    'bg-red-50 text-red-500' => $trx->type === \App\Enums\DesaTransactionType::Expense,
                                ])>
                                    <x-ui.icon :name="$trx->type === \App\Enums\DesaTransactionType::Income ? 'trend-up' : 'wallet'" class="w-5 h-5" />
                                </span>
                                <div class="min-w-0 flex-1">
                                    <p class="font-medium text-slate-800 truncate">{{ $trx->description }}</p>
                                    <p class="text-xs text-slate-400">{{ $trx->transaction_date->translatedFormat('d M Y') }}</p>
                                </div>
                                <span @class([
                                    'text-sm font-bold shrink-0',
                                    'text-emerald-600' => $trx->type === \App\Enums\DesaTransactionType::Income,
                                    'text-red-500' => $trx->type === \App\Enums\DesaTransactionType::Expense,
                                ])>
                                    {{ $trx->type === \App\Enums\DesaTransactionType::Income ? '+' : '−' }} {{ rupiah($trx->amount) }}
                                </span>
                            </div>
                        @endforeach
                    </div>
                </x-ui.card>
            @endif
        </div>
    </div>
</x-app-layout>
