<x-app-layout>
    <x-slot name="header">
        <div class="flex items-center gap-3">
            <span class="w-11 h-11 rounded-2xl bg-brand-600 text-white flex items-center justify-center"><x-ui.icon name="map-pin" class="w-6 h-6" /></span>
            <div>
                <h1 class="text-xl font-bold text-slate-900">Desa Saya</h1>
                <p class="text-sm text-slate-500">Kelola desa Anda atau gabung ke desa lain.</p>
            </div>
        </div>
    </x-slot>

    <x-desa-tabs :desa="$activeDesa" />

    <div class="mt-6 space-y-6">
        @if ($desas->isEmpty())
            {{-- Belum ikut desa mana pun --}}
            <div class="grid sm:grid-cols-2 gap-5">
                <x-ui.card>
                    <span class="w-12 h-12 rounded-2xl bg-brand-50 text-brand-600 flex items-center justify-center"><x-ui.icon name="plus" class="w-6 h-6" /></span>
                    <h3 class="mt-4 font-bold text-slate-900">Buat Desa</h3>
                    <p class="mt-1 text-sm text-slate-600">Bangun desa Anda sendiri. Anda otomatis menjadi Admin.</p>
                    <x-ui.button href="{{ route('desa.create') }}" class="mt-4">Buat Desa <x-ui.icon name="arrow-right" class="w-5 h-5" /></x-ui.button>
                </x-ui.card>

                <x-ui.card>
                    <span class="w-12 h-12 rounded-2xl bg-emerald-50 text-emerald-600 flex items-center justify-center"><x-ui.icon name="users" class="w-6 h-6" /></span>
                    <h3 class="mt-4 font-bold text-slate-900">Gabung Desa</h3>
                    <p class="mt-1 text-sm text-slate-600">Punya kode desa? Masukkan untuk mengirim permintaan bergabung.</p>
                    <form method="POST" action="{{ route('desa.join') }}" class="mt-4 flex gap-2">
                        @csrf
                        <input name="code" value="{{ old('code') }}" placeholder="Kode desa (mis. K7QW2M)" class="field-input uppercase" maxlength="12" required>
                        <x-ui.button type="submit" variant="outline">Gabung</x-ui.button>
                    </form>
                    <x-input-error :messages="$errors->get('code')" class="mt-2" />
                </x-ui.card>
            </div>
        @else
            {{-- Ringkasan desa aktif --}}
            <x-ui.card class="relative overflow-hidden">
                <div aria-hidden="true" class="pointer-events-none absolute -right-8 -top-8 w-36 h-36 rounded-full bg-brand-100/50 blur-2xl"></div>
                <div class="relative flex flex-col sm:flex-row sm:items-start sm:justify-between gap-4">
                    <div class="min-w-0">
                        <div class="flex items-center gap-2 flex-wrap">
                            <h2 class="text-lg font-bold text-slate-900 truncate">{{ $activeDesa->name }}</h2>
                            @if ($activeRole)<x-status-badge :status="$activeRole" />@endif
                        </div>
                        @if ($activeDesa->region)<p class="mt-0.5 text-sm text-slate-500">{{ $activeDesa->region }}</p>@endif
                        @if ($activeDesa->description)<p class="mt-2 text-sm text-slate-600 max-w-prose">{{ $activeDesa->description }}</p>@endif
                        <div class="mt-3 flex items-center gap-4 text-sm text-slate-500">
                            <span class="inline-flex items-center gap-1.5"><x-ui.icon name="users" class="w-4 h-4" /> {{ $activeDesa->members_count }} anggota</span>
                        </div>
                    </div>
                    <div class="shrink-0 rounded-2xl bg-slate-50 ring-1 ring-slate-100 px-4 py-3 text-center">
                        <p class="text-xs text-slate-500">Kode gabung</p>
                        <p class="text-xl font-extrabold tracking-widest text-brand-700">{{ $activeDesa->code }}</p>
                        <p class="text-[11px] text-slate-400 mt-0.5">bagikan agar warga bisa gabung</p>
                    </div>
                </div>

                <div class="relative mt-5 flex flex-wrap gap-2">
                    <x-ui.button href="{{ route('desa.members', $activeDesa) }}" variant="outline" size="sm"><x-ui.icon name="users" class="w-4 h-4" /> Daftar Anggota</x-ui.button>
                    @can('reviewRequests', $activeDesa)
                        <x-ui.button href="{{ route('desa.requests', $activeDesa) }}" variant="outline" size="sm"><x-ui.icon name="inbox" class="w-4 h-4" /> Permintaan Bergabung</x-ui.button>
                    @endcan
                    @can('update', $activeDesa)
                        <x-ui.button href="{{ route('desa.settings', $activeDesa) }}" variant="outline" size="sm"><x-ui.icon name="adjust" class="w-4 h-4" /> Pengaturan</x-ui.button>
                    @endcan
                </div>
            </x-ui.card>

            {{-- Daftar desa yang saya ikuti + beralih --}}
            <div>
                <h3 class="text-sm font-semibold text-slate-500 mb-2">Desa yang saya ikuti</h3>
                <div class="space-y-2">
                    @foreach ($desas as $d)
                        @php($role = \App\Enums\DesaRole::from($d->pivot->role))
                        <x-ui.card padding="p-4" class="flex items-center gap-4">
                            <span class="w-10 h-10 rounded-xl bg-brand-50 text-brand-600 flex items-center justify-center shrink-0"><x-ui.icon name="map-pin" class="w-5 h-5" /></span>
                            <div class="min-w-0 flex-1">
                                <p class="font-semibold text-slate-800 truncate">{{ $d->name }}</p>
                                <p class="text-xs text-slate-500">{{ $d->members_count }} anggota</p>
                            </div>
                            <x-status-badge :status="$role" />
                            @if ($activeDesa && $d->id === $activeDesa->id)
                                <span class="inline-flex items-center gap-1 text-xs font-semibold text-brand-600"><x-ui.icon name="check" class="w-4 h-4" /> Aktif</span>
                            @else
                                <form method="POST" action="{{ route('desa.switch', $d) }}">
                                    @csrf
                                    <button type="submit" class="text-sm font-semibold text-slate-500 hover:text-brand-700">Jadikan aktif</button>
                                </form>
                            @endif
                        </x-ui.card>
                    @endforeach
                </div>
            </div>

            {{-- Buat / gabung desa lain --}}
            <x-ui.card padding="p-4" class="flex flex-col sm:flex-row sm:items-center gap-3">
                <form method="POST" action="{{ route('desa.join') }}" class="flex gap-2 flex-1">
                    @csrf
                    <input name="code" value="{{ old('code') }}" placeholder="Masukkan kode desa lain" class="field-input uppercase" maxlength="12" required>
                    <x-ui.button type="submit" variant="outline">Gabung</x-ui.button>
                </form>
                <x-ui.button href="{{ route('desa.create') }}"><x-ui.icon name="plus" class="w-5 h-5" /> Buat Desa</x-ui.button>
            </x-ui.card>
            <x-input-error :messages="$errors->get('code')" />
        @endif

        {{-- Permintaan yang sedang menunggu --}}
        @if ($pendingRequests->isNotEmpty())
            <x-ui.card padding="p-4">
                <h3 class="text-sm font-semibold text-slate-500 mb-2">Permintaan bergabung Anda</h3>
                <div class="space-y-2">
                    @foreach ($pendingRequests as $req)
                        <div class="flex items-center justify-between gap-3">
                            <span class="text-sm text-slate-700">{{ $req->desa->name }}</span>
                            <x-status-badge :status="$req->status" />
                        </div>
                    @endforeach
                </div>
            </x-ui.card>
        @endif
    </div>
</x-app-layout>
