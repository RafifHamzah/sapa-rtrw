<x-app-layout>
    <x-slot name="header">
        <div class="flex items-center gap-3">
            <span class="w-11 h-11 rounded-2xl bg-brand-600 text-white flex items-center justify-center"><x-ui.icon name="adjust" class="w-6 h-6" /></span>
            <div>
                <h1 class="text-xl font-bold text-slate-900">Pengaturan Desa</h1>
                <p class="text-sm text-slate-500">{{ $desa->name }}</p>
            </div>
        </div>
    </x-slot>

    <x-desa-tabs :desa="$desa" />

    <div class="mt-6 max-w-2xl space-y-6">
        {{-- Kode gabung (read-only) --}}
        <x-ui.card padding="p-4" class="flex items-center justify-between gap-4">
            <div>
                <p class="text-sm font-semibold text-slate-700">Kode gabung desa</p>
                <p class="text-xs text-slate-500">Bagikan kode ini agar warga dapat mengajukan bergabung.</p>
            </div>
            <span class="rounded-xl bg-slate-50 ring-1 ring-slate-100 px-4 py-2 text-lg font-extrabold tracking-widest text-brand-700">{{ $desa->code }}</span>
        </x-ui.card>

        <x-ui.card>
            <form method="POST" action="{{ route('desa.update', $desa) }}" class="space-y-4">
                @csrf
                @method('PATCH')

                <div>
                    <label for="name" class="block text-sm font-medium text-slate-700 mb-1">Nama Desa <span class="text-red-500">*</span></label>
                    <input id="name" name="name" value="{{ old('name', $desa->name) }}" class="field-input" required maxlength="255">
                    <x-input-error :messages="$errors->get('name')" class="mt-1" />
                </div>

                <div>
                    <label for="region" class="block text-sm font-medium text-slate-700 mb-1">Wilayah</label>
                    <input id="region" name="region" value="{{ old('region', $desa->region) }}" class="field-input" maxlength="255">
                    <x-input-error :messages="$errors->get('region')" class="mt-1" />
                </div>

                <div>
                    <label for="address" class="block text-sm font-medium text-slate-700 mb-1">Alamat</label>
                    <input id="address" name="address" value="{{ old('address', $desa->address) }}" class="field-input" maxlength="255">
                    <x-input-error :messages="$errors->get('address')" class="mt-1" />
                </div>

                <div>
                    <label for="description" class="block text-sm font-medium text-slate-700 mb-1">Deskripsi</label>
                    <textarea id="description" name="description" rows="3" class="field-input" maxlength="2000">{{ old('description', $desa->description) }}</textarea>
                    <x-input-error :messages="$errors->get('description')" class="mt-1" />
                </div>

                <div class="pt-2">
                    <x-ui.button type="submit" size="lg">Simpan Perubahan</x-ui.button>
                </div>
            </form>
        </x-ui.card>
    </div>
</x-app-layout>
