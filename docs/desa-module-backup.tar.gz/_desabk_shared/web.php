<?php

use App\Http\Controllers\AccountStatusController;
use App\Http\Controllers\AnnouncementController;
use App\Http\Controllers\AssistantController;
use App\Http\Controllers\ComplaintController;
use App\Http\Controllers\DashboardController;
use App\Http\Controllers\DesaController;
use App\Http\Controllers\DesaDuesController;
use App\Http\Controllers\DesaJoinRequestController;
use App\Http\Controllers\DesaKasController;
use App\Http\Controllers\DesaMemberController;
use App\Http\Controllers\GameController;
use App\Http\Controllers\GamificationController;
use App\Http\Controllers\KasController;
use App\Http\Controllers\LetterController;
use App\Http\Controllers\LetterVerificationController;
use App\Http\Controllers\PaymentController;
use App\Http\Controllers\ProfileController;
use Illuminate\Support\Facades\Route;

Route::get('/', function () {
    // Landing publik tetap tampil walau DB belum siap (rescue → 0).
    return view('welcome', [
        'stats' => [
            'families' => rescue(fn () => \App\Models\Family::count(), 0, false),
            'residents' => rescue(fn () => \App\Models\Resident::count(), 0, false),
            'letters' => rescue(fn () => \App\Models\LetterRequest::whereNotNull('letter_number')->count(), 0, false),
            'transactions' => rescue(fn () => \App\Models\Transaction::count(), 0, false),
        ],
    ]);
});

// Halaman status akun — dapat diakses warga pending/rejected (tanpa gate verifikasi).
Route::get('/account/status', AccountStatusController::class)
    ->middleware('auth')
    ->name('account.status');

// Dashboard & fitur warga hanya untuk akun yang sudah terverifikasi.
Route::get('/dashboard', DashboardController::class)
    ->middleware(['auth', 'verified', 'verified.resident'])->name('dashboard');

Route::middleware(['auth', 'verified.resident'])->group(function () {
    Route::get('/profile', [ProfileController::class, 'edit'])->name('profile.edit');
    Route::patch('/profile', [ProfileController::class, 'update'])->name('profile.update');
    Route::delete('/profile', [ProfileController::class, 'destroy'])->name('profile.destroy');

    // Kas transparan (read-only) & Iuran saya (pembayaran Midtrans via Livewire).
    Route::get('/kas', [KasController::class, 'index'])->name('kas.index');
    Route::view('/iuran', 'iuran.index')->name('iuran.index');

    // Gamifikasi: profil prestasi & papan peringkat.
    Route::get('/profil', [GamificationController::class, 'profile'])->name('profile.show');
    Route::get('/peringkat', [GamificationController::class, 'leaderboard'])->name('leaderboard');

    // SAPA AI — asisten FAQ.
    Route::post('/assistant/ask', [AssistantController::class, 'ask'])->name('assistant.ask');

    // Belajar Sambil Bermain (mini-game edukasi).
    Route::get('/game', [GameController::class, 'index'])->name('game.index');
    Route::get('/game/pilah-sampah', [GameController::class, 'pilahSampah'])->name('game.pilah-sampah');
    Route::get('/game/kuis-administrasi', [GameController::class, 'kuisAdministrasi'])->name('game.kuis-administrasi');
    Route::get('/game/tebak-surat', [GameController::class, 'tebakSurat'])->name('game.tebak-surat');
    Route::post('/game/{game}/complete', [GameController::class, 'complete'])->name('game.complete');
});

// Pembayaran iuran online (Midtrans).
Route::post('/dues/{dues}/pay', [PaymentController::class, 'pay'])
    ->middleware(['auth', 'verified.resident'])
    ->name('dues.pay');

// Webhook Midtrans — tanpa auth, dikecualikan dari CSRF (lihat bootstrap/app.php).
Route::post('/midtrans/callback', [PaymentController::class, 'callback'])
    ->name('midtrans.callback');

// Verifikasi surat publik (tanpa login).
Route::get('/verify/{qr_token}', LetterVerificationController::class)->name('letters.verify');

// Surat pengantar (warga terverifikasi).
Route::middleware(['auth', 'verified.resident'])->group(function () {
    Route::get('/letters', [LetterController::class, 'index'])->name('letters.index');
    Route::post('/letters', [LetterController::class, 'store'])->name('letters.store');
    Route::get('/letters/{letter}/download', [LetterController::class, 'download'])->name('letters.download');

    // Pengumuman (feed warga) & Lapor Warga (pengaduan).
    Route::get('/announcements', [AnnouncementController::class, 'index'])->name('announcements.index');
    Route::get('/announcements/{announcement}', [AnnouncementController::class, 'show'])->name('announcements.show');
    Route::get('/complaints', [ComplaintController::class, 'index'])->name('complaints.index');
    Route::post('/complaints', [ComplaintController::class, 'store'])->name('complaints.store');
    Route::get('/complaints/{complaint}', [ComplaintController::class, 'show'])->name('complaints.show');
});

// ===== Modul Desa (multi-tenant, role per-desa) =====
Route::middleware(['auth', 'verified.resident'])->prefix('desa')->name('desa.')->group(function () {
    Route::get('/', [DesaController::class, 'index'])->name('index');
    Route::get('/buat', [DesaController::class, 'create'])->name('create');
    Route::post('/', [DesaController::class, 'store'])->name('store');
    Route::post('/gabung', [DesaController::class, 'join'])->name('join');
    Route::post('/{desa}/switch', [DesaController::class, 'switch'])->name('switch');

    // Daftar Anggota + ubah role.
    Route::get('/{desa}/anggota', [DesaMemberController::class, 'index'])->name('members');
    Route::patch('/{desa}/anggota/{member}/role', [DesaMemberController::class, 'updateRole'])->name('members.role');

    // Permintaan Bergabung (Admin/Staff).
    Route::get('/{desa}/permintaan', [DesaJoinRequestController::class, 'index'])->name('requests');
    Route::post('/{desa}/permintaan/{joinRequest}/approve', [DesaJoinRequestController::class, 'approve'])->name('requests.approve');
    Route::post('/{desa}/permintaan/{joinRequest}/reject', [DesaJoinRequestController::class, 'reject'])->name('requests.reject');

    // Pengaturan Desa (Admin).
    Route::get('/{desa}/pengaturan', [DesaController::class, 'settings'])->name('settings');
    Route::patch('/{desa}/pengaturan', [DesaController::class, 'update'])->name('update');

    // Kas Desa (transparan; catat = Admin/Staff).
    Route::get('/{desa}/kas', [DesaKasController::class, 'index'])->name('kas');
    Route::post('/{desa}/kas', [DesaKasController::class, 'store'])->name('kas.store');

    // Iuran Desa (lihat = anggota; kelola = Admin/Staff; bayar online = Midtrans).
    Route::get('/{desa}/iuran', [DesaDuesController::class, 'index'])->name('iuran');
    Route::post('/{desa}/iuran', [DesaDuesController::class, 'store'])->name('iuran.store');
    Route::post('/{desa}/iuran/generate', [DesaDuesController::class, 'generate'])->name('iuran.generate');
    Route::post('/{desa}/iuran/{dues}/pay', [DesaDuesController::class, 'pay'])->name('iuran.pay');
    Route::post('/{desa}/iuran/{dues}/sync', [DesaDuesController::class, 'sync'])->name('iuran.sync');
    Route::post('/{desa}/iuran/{dues}/mark-paid', [DesaDuesController::class, 'markPaid'])->name('iuran.markPaid');
});

require __DIR__.'/auth.php';
