<?php

namespace App\Http\Controllers;

use Illuminate\Foundation\Auth\Access\AuthorizesRequests;

abstract class Controller
{
    // Memungkinkan $this->authorize(...) memakai Policy (dipakai modul Desa).
    use AuthorizesRequests;
}
