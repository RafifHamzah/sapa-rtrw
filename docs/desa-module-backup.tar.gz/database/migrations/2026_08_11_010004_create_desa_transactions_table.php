<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('desa_transactions', function (Blueprint $table) {
            $table->id();
            $table->foreignId('desa_id')->constrained('desas')->cascadeOnDelete();
            $table->string('type');                 // income | expense
            $table->unsignedBigInteger('amount');
            $table->string('description');
            $table->date('transaction_date');
            // Tautan idempoten ke iuran (agar 1 iuran lunas = 1 pemasukan kas).
            $table->foreignId('desa_dues_id')->nullable()->constrained('desa_dues')->nullOnDelete();
            $table->foreignId('created_by')->nullable()->constrained('users')->nullOnDelete();
            $table->timestamps();
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('desa_transactions');
    }
};
