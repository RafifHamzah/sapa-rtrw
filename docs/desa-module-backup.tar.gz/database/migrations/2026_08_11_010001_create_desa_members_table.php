<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('desa_members', function (Blueprint $table) {
            $table->id();
            $table->foreignId('desa_id')->constrained('desas')->cascadeOnDelete();
            $table->foreignId('user_id')->constrained('users')->cascadeOnDelete();
            // Role PER-DESA (bukan role Spatie global): admin | staff | warga.
            $table->string('role')->default('warga');
            $table->timestamp('joined_at')->nullable();
            $table->timestamps();

            // Satu user hanya punya satu keanggotaan per desa.
            $table->unique(['desa_id', 'user_id']);
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('desa_members');
    }
};
