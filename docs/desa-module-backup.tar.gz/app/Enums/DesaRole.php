<?php

namespace App\Enums;

use Filament\Support\Contracts\HasColor;
use Filament\Support\Contracts\HasLabel;

/**
 * Role PER-DESA (disimpan di pivot desa_members). Terpisah dari role Spatie
 * global; setiap user bisa punya role berbeda di tiap desa yang diikuti.
 */
enum DesaRole: string implements HasLabel, HasColor
{
    case Admin = 'admin';
    case Staff = 'staff';
    case Warga = 'warga';

    public function getLabel(): string
    {
        return match ($this) {
            self::Admin => 'Admin',
            self::Staff => 'Staff',
            self::Warga => 'Warga',
        };
    }

    public function getColor(): string
    {
        return match ($this) {
            self::Admin => 'success',
            self::Staff => 'info',
            self::Warga => 'gray',
        };
    }

    /** Boleh meninjau (approve/reject) permintaan bergabung. */
    public function canReviewRequests(): bool
    {
        return in_array($this, [self::Admin, self::Staff], true);
    }

    /** Boleh mengubah role anggota. */
    public function canManageRoles(): bool
    {
        return $this === self::Admin;
    }

    /** Boleh mengubah pengaturan desa. */
    public function canManageDesa(): bool
    {
        return $this === self::Admin;
    }

    /** Boleh mengelola keuangan desa (catat kas, buat & tandai iuran). */
    public function canManageFinance(): bool
    {
        return in_array($this, [self::Admin, self::Staff], true);
    }

    /** Opsi untuk <select> ubah role. */
    public static function options(): array
    {
        return collect(self::cases())
            ->mapWithKeys(fn (self $r) => [$r->value => $r->getLabel()])
            ->all();
    }
}
