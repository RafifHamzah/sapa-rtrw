<?php

namespace App\Enums;

use Filament\Support\Contracts\HasColor;
use Filament\Support\Contracts\HasLabel;

enum DesaDuesStatus: string implements HasLabel, HasColor
{
    case Unpaid = 'unpaid';
    case Pending = 'pending';   // menunggu pembayaran online selesai
    case Paid = 'paid';

    public function getLabel(): string
    {
        return match ($this) {
            self::Unpaid => 'Belum Bayar',
            self::Pending => 'Diproses',
            self::Paid => 'Lunas',
        };
    }

    public function getColor(): string
    {
        return match ($this) {
            self::Unpaid => 'warning',
            self::Pending => 'info',
            self::Paid => 'success',
        };
    }
}
