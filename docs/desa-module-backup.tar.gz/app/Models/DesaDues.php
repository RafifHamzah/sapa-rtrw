<?php

namespace App\Models;

use App\Enums\DesaDuesStatus;
use Carbon\Carbon;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\HasOne;

class DesaDues extends Model
{
    protected $table = 'desa_dues';

    protected $fillable = [
        'desa_id',
        'user_id',
        'amount',
        'period_month',
        'period_year',
        'due_date',
        'status',
        'method',
        'midtrans_order_id',
        'midtrans_status',
        'midtrans_transaction_id',
        'paid_at',
        'recorded_by',
    ];

    protected function casts(): array
    {
        return [
            'amount' => 'integer',
            'period_month' => 'integer',
            'period_year' => 'integer',
            'due_date' => 'date',
            'status' => DesaDuesStatus::class,
            'paid_at' => 'datetime',
        ];
    }

    public function desa(): BelongsTo
    {
        return $this->belongsTo(Desa::class);
    }

    public function user(): BelongsTo
    {
        return $this->belongsTo(User::class);
    }

    /** Entri kas (pemasukan) yang dihasilkan saat iuran ini lunas. */
    public function transaction(): HasOne
    {
        return $this->hasOne(DesaTransaction::class, 'desa_dues_id');
    }

    public function isPaid(): bool
    {
        return $this->status === DesaDuesStatus::Paid;
    }

    public function periodLabel(): string
    {
        return Carbon::create()->month($this->period_month)->translatedFormat('F') . ' ' . $this->period_year;
    }
}
