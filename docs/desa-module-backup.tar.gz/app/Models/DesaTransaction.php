<?php

namespace App\Models;

use App\Enums\DesaTransactionType;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;

class DesaTransaction extends Model
{
    protected $fillable = [
        'desa_id',
        'type',
        'amount',
        'description',
        'transaction_date',
        'desa_dues_id',
        'created_by',
    ];

    protected function casts(): array
    {
        return [
            'type' => DesaTransactionType::class,
            'amount' => 'integer',
            'transaction_date' => 'date',
        ];
    }

    public function desa(): BelongsTo
    {
        return $this->belongsTo(Desa::class);
    }

    public function dues(): BelongsTo
    {
        return $this->belongsTo(DesaDues::class, 'desa_dues_id');
    }

    public function recorder(): BelongsTo
    {
        return $this->belongsTo(User::class, 'created_by');
    }
}
