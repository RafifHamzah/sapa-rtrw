<?php

namespace App\Models;

use App\Enums\DesaRole;
use App\Enums\DesaTransactionType;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\BelongsToMany;
use Illuminate\Database\Eloquent\Relations\HasMany;
use Illuminate\Support\Str;

class Desa extends Model
{
    use HasFactory;

    protected $fillable = [
        'created_by',
        'name',
        'code',
        'description',
        'region',
        'address',
    ];

    // --- Relations ----------------------------------------------------------

    public function owner(): BelongsTo
    {
        return $this->belongsTo(User::class, 'created_by');
    }

    public function members(): HasMany
    {
        return $this->hasMany(DesaMember::class);
    }

    public function users(): BelongsToMany
    {
        return $this->belongsToMany(User::class, 'desa_members')
            ->withPivot('role', 'joined_at')
            ->withTimestamps();
    }

    public function joinRequests(): HasMany
    {
        return $this->hasMany(DesaJoinRequest::class);
    }

    public function transactions(): HasMany
    {
        return $this->hasMany(DesaTransaction::class)->latest('transaction_date')->latest('id');
    }

    public function dues(): HasMany
    {
        return $this->hasMany(DesaDues::class);
    }

    // --- Helpers ------------------------------------------------------------

    /** Saldo kas desa = total pemasukan − total pengeluaran. */
    public function kasBalance(): int
    {
        $income = (int) $this->transactions()->where('type', DesaTransactionType::Income->value)->sum('amount');
        $expense = (int) $this->transactions()->where('type', DesaTransactionType::Expense->value)->sum('amount');

        return $income - $expense;
    }

    /** Keanggotaan seorang user di desa ini (atau null). */
    public function memberFor(User $user): ?DesaMember
    {
        return $this->members->firstWhere('user_id', $user->id)
            ?? $this->members()->where('user_id', $user->id)->first();
    }

    public function roleFor(User $user): ?DesaRole
    {
        return $this->memberFor($user)?->role;
    }

    public function hasMember(User $user): bool
    {
        return $this->memberFor($user) !== null;
    }

    public function isAdmin(User $user): bool
    {
        return $this->roleFor($user) === DesaRole::Admin;
    }

    /** Buat kode gabung unik (mis. "K7QW2M"). */
    public static function generateCode(): string
    {
        do {
            $code = Str::upper(Str::random(6));
        } while (static::where('code', $code)->exists());

        return $code;
    }
}
