<?php

namespace App\Services;

use App\Enums\DesaDuesStatus;
use App\Enums\DesaTransactionType;
use App\Models\DesaDues;
use App\Models\DesaTransaction;
use App\Models\User;
use Illuminate\Support\Facades\DB;

class DesaFinanceService
{
    /**
     * Tandai iuran desa lunas lalu posting sebagai pemasukan kas desa.
     * Idempoten: satu iuran hanya menghasilkan satu entri kas (aman dipanggil
     * ulang dari webhook / cek-status / tandai manual). $method: manual|online.
     */
    public function settle(DesaDues $dues, string $method, ?User $by = null): void
    {
        DB::transaction(function () use ($dues, $method, $by): void {
            $dues = DesaDues::whereKey($dues->getKey())->lockForUpdate()->first();

            if (! $dues) {
                return;
            }

            if ($dues->status !== DesaDuesStatus::Paid) {
                $dues->update([
                    'status' => DesaDuesStatus::Paid,
                    'method' => $method,
                    'paid_at' => $dues->paid_at ?? now(),
                    'recorded_by' => $by?->id ?? $dues->recorded_by,
                ]);
            }

            if (! $dues->transaction()->exists()) {
                DesaTransaction::create([
                    'desa_id' => $dues->desa_id,
                    'type' => DesaTransactionType::Income,
                    'amount' => $dues->amount,
                    'description' => 'Iuran ' . ($dues->user->name ?? 'warga') . ' — ' . $dues->periodLabel(),
                    'transaction_date' => ($dues->paid_at ?? now())->toDateString(),
                    'desa_dues_id' => $dues->id,
                    'created_by' => $by?->id,
                ]);
            }
        });
    }
}
