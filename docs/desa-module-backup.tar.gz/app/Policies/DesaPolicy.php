<?php

namespace App\Policies;

use App\Models\Desa;
use App\Models\User;

/**
 * Otorisasi modul Desa. SELALU dievaluasi terhadap desa spesifik ($desa),
 * sehingga permission satu desa tidak pernah bocor ke desa lain — role diambil
 * dari keanggotaan (desa_members) untuk desa itu.
 */
class DesaPolicy
{
    /** Lihat desa & daftar anggota — semua anggota. */
    public function view(User $user, Desa $desa): bool
    {
        return $desa->hasMember($user);
    }

    /** Tinjau (approve/reject) permintaan bergabung — Admin & Staff. */
    public function reviewRequests(User $user, Desa $desa): bool
    {
        return (bool) $desa->roleFor($user)?->canReviewRequests();
    }

    /** Ubah role anggota — hanya Admin. */
    public function manageRoles(User $user, Desa $desa): bool
    {
        return (bool) $desa->roleFor($user)?->canManageRoles();
    }

    /** Ubah pengaturan desa — hanya Admin. */
    public function update(User $user, Desa $desa): bool
    {
        return (bool) $desa->roleFor($user)?->canManageDesa();
    }

    /** Kelola keuangan (catat kas, buat/tandai iuran) — Admin & Staff. */
    public function manageFinance(User $user, Desa $desa): bool
    {
        return (bool) $desa->roleFor($user)?->canManageFinance();
    }
}
