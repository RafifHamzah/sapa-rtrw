<?php

namespace App\Http\Controllers;

use App\Enums\DesaJoinStatus;
use App\Enums\DesaRole;
use App\Models\Desa;
use App\Models\DesaMember;
use Illuminate\Contracts\View\View;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class DesaController extends Controller
{
    /**
     * "Desa Saya": ringkasan desa aktif + daftar desa yang diikuti. Jika belum
     * punya desa, tampilkan opsi buat/gabung.
     */
    public function index(Request $request): View
    {
        $user = $request->user();

        $desas = $user->desas()->withCount('members')->get();

        // Desa aktif diambil dari koleksi ber-count agar tak query ulang.
        $activeId = session('current_desa_id');
        $activeDesa = $desas->firstWhere('id', $activeId) ?? $desas->first();

        // Request bergabung yang masih diproses (untuk info status).
        $pendingRequests = $user->desaJoinRequests()
            ->where('status', DesaJoinStatus::Pending)
            ->with('desa')
            ->get();

        return view('desa.index', [
            'desas' => $desas,
            'activeDesa' => $activeDesa,
            'activeRole' => $activeDesa ? $user->desaRole($activeDesa) : null,
            'pendingRequests' => $pendingRequests,
        ]);
    }

    /** Form buat desa. */
    public function create(): View
    {
        return view('desa.create');
    }

    /**
     * Simpan desa baru. Pembuat OTOMATIS menjadi Admin desa tersebut.
     */
    public function store(Request $request): RedirectResponse
    {
        $data = $request->validate([
            'name' => ['required', 'string', 'max:255'],
            'description' => ['nullable', 'string', 'max:2000'],
            'region' => ['nullable', 'string', 'max:255'],
            'address' => ['nullable', 'string', 'max:255'],
        ]);

        $user = $request->user();

        $desa = DB::transaction(function () use ($data, $user): Desa {
            $desa = Desa::create([
                'created_by' => $user->id,
                'name' => $data['name'],
                'code' => Desa::generateCode(),
                'description' => $data['description'] ?? null,
                'region' => $data['region'] ?? null,
                'address' => $data['address'] ?? null,
            ]);

            // Pembuat = Admin.
            DesaMember::create([
                'desa_id' => $desa->id,
                'user_id' => $user->id,
                'role' => DesaRole::Admin,
                'joined_at' => now(),
            ]);

            return $desa;
        });

        session(['current_desa_id' => $desa->id]);

        return redirect()
            ->route('desa.index')
            ->with('status', "Desa \"{$desa->name}\" berhasil dibuat. Kode gabung: {$desa->code}")
            ->with('celebrate', true);
    }

    /**
     * Kirim permintaan bergabung berdasarkan kode desa.
     */
    public function join(Request $request): RedirectResponse
    {
        $data = $request->validate([
            'code' => ['required', 'string', 'max:12'],
        ]);

        $user = $request->user();
        $desa = Desa::where('code', strtoupper(trim($data['code'])))->first();

        if (! $desa) {
            return back()->withErrors(['code' => 'Kode desa tidak ditemukan.'])->withInput();
        }

        if ($desa->hasMember($user)) {
            session(['current_desa_id' => $desa->id]);

            return redirect()->route('desa.index')
                ->with('status', "Anda sudah menjadi anggota desa \"{$desa->name}\".");
        }

        // Satu baris request per (desa,user): dipakai ulang bila request ulang.
        $existing = $desa->joinRequests()->where('user_id', $user->id)->first();

        if ($existing && $existing->status === DesaJoinStatus::Pending) {
            return back()->with('status', 'Permintaan Anda masih menunggu persetujuan admin desa.');
        }

        $desa->joinRequests()->updateOrCreate(
            ['user_id' => $user->id],
            [
                'status' => DesaJoinStatus::Pending,
                'message' => null,
                'reviewed_by' => null,
                'reviewed_at' => null,
            ],
        );

        return back()->with('status', "Permintaan bergabung ke \"{$desa->name}\" terkirim. Menunggu persetujuan admin.");
    }

    /** Ganti desa aktif (konteks nav). Hanya untuk desa yang diikuti. */
    public function switch(Request $request, Desa $desa): RedirectResponse
    {
        abort_unless($desa->hasMember($request->user()), 403);

        session(['current_desa_id' => $desa->id]);

        return back()->with('status', "Beralih ke desa \"{$desa->name}\".");
    }

    /** Form pengaturan desa (Admin). */
    public function settings(Desa $desa): View
    {
        $this->authorize('update', $desa);

        return view('desa.settings', ['desa' => $desa]);
    }

    /** Simpan pengaturan desa (Admin). */
    public function update(Request $request, Desa $desa): RedirectResponse
    {
        $this->authorize('update', $desa);

        $data = $request->validate([
            'name' => ['required', 'string', 'max:255'],
            'description' => ['nullable', 'string', 'max:2000'],
            'region' => ['nullable', 'string', 'max:255'],
            'address' => ['nullable', 'string', 'max:255'],
        ]);

        $desa->update($data);

        return back()->with('status', 'Pengaturan desa disimpan.');
    }
}
