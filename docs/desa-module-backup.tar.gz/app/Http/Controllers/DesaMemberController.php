<?php

namespace App\Http\Controllers;

use App\Enums\DesaRole;
use App\Models\Desa;
use App\Models\DesaMember;
use Illuminate\Contracts\View\View;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;
use Illuminate\Validation\Rule;

class DesaMemberController extends Controller
{
    /** Daftar anggota desa (semua anggota boleh lihat). */
    public function index(Request $request, Desa $desa): View
    {
        $this->authorize('view', $desa);

        $members = $desa->members()
            ->with('user')
            ->orderByRaw("CASE role WHEN 'admin' THEN 0 WHEN 'staff' THEN 1 ELSE 2 END")
            ->orderBy('joined_at')
            ->get();

        return view('desa.members', [
            'desa' => $desa,
            'members' => $members,
            'canManageRoles' => $request->user()->can('manageRoles', $desa),
        ]);
    }

    /** Ubah role anggota (hanya Admin). */
    public function updateRole(Request $request, Desa $desa, DesaMember $member): RedirectResponse
    {
        $this->authorize('manageRoles', $desa);

        // Pastikan anggota memang milik desa ini (cegah cross-desa).
        abort_unless($member->desa_id === $desa->id, 404);

        $data = $request->validate([
            'role' => ['required', Rule::enum(DesaRole::class)],
        ]);

        $newRole = DesaRole::from($data['role']);

        // Jangan sampai desa kehilangan Admin terakhir.
        if ($member->role === DesaRole::Admin && $newRole !== DesaRole::Admin) {
            $adminCount = $desa->members()->where('role', DesaRole::Admin->value)->count();

            if ($adminCount <= 1) {
                return back()->withErrors([
                    'role' => 'Tidak bisa menurunkan Admin terakhir. Tunjuk Admin lain dulu.',
                ]);
            }
        }

        $member->update(['role' => $newRole]);

        return back()->with('status', "Role {$member->user->name} diubah menjadi {$newRole->getLabel()}.");
    }
}
