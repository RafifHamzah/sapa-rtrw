<?php

namespace App\Http\Controllers;

use App\Enums\DesaJoinStatus;
use App\Enums\DesaRole;
use App\Models\Desa;
use App\Models\DesaJoinRequest;
use App\Models\DesaMember;
use Illuminate\Contracts\View\View;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class DesaJoinRequestController extends Controller
{
    /** Daftar permintaan bergabung (Admin & Staff). */
    public function index(Request $request, Desa $desa): View
    {
        $this->authorize('reviewRequests', $desa);

        $requests = $desa->joinRequests()
            ->with('user')
            ->orderByRaw("CASE status WHEN 'pending' THEN 0 ELSE 1 END")
            ->latest()
            ->get();

        return view('desa.requests', [
            'desa' => $desa,
            'requests' => $requests,
        ]);
    }

    /** Terima permintaan → jadikan anggota (role Warga). Idempoten. */
    public function approve(Request $request, Desa $desa, DesaJoinRequest $joinRequest): RedirectResponse
    {
        $this->authorize('reviewRequests', $desa);
        abort_unless($joinRequest->desa_id === $desa->id, 404);

        DB::transaction(function () use ($desa, $joinRequest, $request): void {
            // Tautkan sebagai anggota bila belum (idempoten).
            DesaMember::firstOrCreate(
                ['desa_id' => $desa->id, 'user_id' => $joinRequest->user_id],
                ['role' => DesaRole::Warga, 'joined_at' => now()],
            );

            $joinRequest->update([
                'status' => DesaJoinStatus::Approved,
                'reviewed_by' => $request->user()->id,
                'reviewed_at' => now(),
            ]);
        });

        return back()->with('status', "Permintaan {$joinRequest->user->name} diterima. Kini menjadi anggota.");
    }

    /** Tolak permintaan bergabung. */
    public function reject(Request $request, Desa $desa, DesaJoinRequest $joinRequest): RedirectResponse
    {
        $this->authorize('reviewRequests', $desa);
        abort_unless($joinRequest->desa_id === $desa->id, 404);

        $joinRequest->update([
            'status' => DesaJoinStatus::Rejected,
            'reviewed_by' => $request->user()->id,
            'reviewed_at' => now(),
        ]);

        return back()->with('status', "Permintaan {$joinRequest->user->name} ditolak.");
    }
}
