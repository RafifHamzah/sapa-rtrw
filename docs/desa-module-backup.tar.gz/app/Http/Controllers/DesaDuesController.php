<?php

namespace App\Http\Controllers;

use App\Enums\DesaDuesStatus;
use App\Models\Desa;
use App\Models\DesaDues;
use App\Services\DesaFinanceService;
use App\Services\MidtransService;
use Illuminate\Contracts\View\View;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Str;
use Illuminate\Validation\Rule;
use Throwable;

class DesaDuesController extends Controller
{
    public function __construct(
        private readonly MidtransService $midtrans,
        private readonly DesaFinanceService $finance,
    ) {}

    /**
     * Halaman iuran desa. Anggota melihat tagihannya sendiri; Admin/Staff juga
     * melihat panel kelola (buat/generate/tandai lunas) semua tagihan.
     */
    public function index(Request $request, Desa $desa): View
    {
        $this->authorize('view', $desa);

        $user = $request->user();
        $canManage = $user->can('manageFinance', $desa);

        $myDues = $desa->dues()
            ->where('user_id', $user->id)
            ->orderByDesc('period_year')->orderByDesc('period_month')
            ->get();

        $allDues = null;
        $members = null;

        if ($canManage) {
            $allDues = $desa->dues()->with('user')
                ->orderByDesc('period_year')->orderByDesc('period_month')
                ->get();
            $members = $desa->members()->with('user')->get();
        }

        return view('desa.iuran', compact('desa', 'myDues', 'allDues', 'members', 'canManage'));
    }

    /** Buat satu tagihan untuk seorang anggota (Admin/Staff). */
    public function store(Request $request, Desa $desa): RedirectResponse
    {
        $this->authorize('manageFinance', $desa);

        $data = $request->validate([
            'user_id' => ['required', 'integer', Rule::exists('desa_members', 'user_id')->where('desa_id', $desa->id)],
            'amount' => ['required', 'integer', 'min:1'],
            'period_month' => ['required', 'integer', 'between:1,12'],
            'period_year' => ['required', 'integer', 'min:2020', 'max:2100'],
            'due_date' => ['nullable', 'date'],
        ]);

        $exists = $desa->dues()
            ->where('user_id', $data['user_id'])
            ->where('period_month', $data['period_month'])
            ->where('period_year', $data['period_year'])
            ->exists();

        if ($exists) {
            return back()->withErrors(['user_id' => 'Tagihan untuk anggota & periode ini sudah ada.']);
        }

        $desa->dues()->create([
            'user_id' => $data['user_id'],
            'amount' => $data['amount'],
            'period_month' => $data['period_month'],
            'period_year' => $data['period_year'],
            'due_date' => $data['due_date'] ?? null,
            'status' => DesaDuesStatus::Unpaid,
        ]);

        return back()->with('status', 'Tagihan iuran dibuat.');
    }

    /** Generate tagihan untuk SEMUA anggota pada satu periode (idempoten). */
    public function generate(Request $request, Desa $desa): RedirectResponse
    {
        $this->authorize('manageFinance', $desa);

        $data = $request->validate([
            'amount' => ['required', 'integer', 'min:1'],
            'period_month' => ['required', 'integer', 'between:1,12'],
            'period_year' => ['required', 'integer', 'min:2020', 'max:2100'],
            'due_date' => ['nullable', 'date'],
        ]);

        $created = 0;

        DB::transaction(function () use ($desa, $data, &$created): void {
            foreach ($desa->members()->get() as $member) {
                $exists = $desa->dues()
                    ->where('user_id', $member->user_id)
                    ->where('period_month', $data['period_month'])
                    ->where('period_year', $data['period_year'])
                    ->exists();

                if ($exists) {
                    continue;
                }

                $desa->dues()->create([
                    'user_id' => $member->user_id,
                    'amount' => $data['amount'],
                    'period_month' => $data['period_month'],
                    'period_year' => $data['period_year'],
                    'due_date' => $data['due_date'] ?? null,
                    'status' => DesaDuesStatus::Unpaid,
                ]);

                $created++;
            }
        });

        return back()->with('status', "Berhasil membuat {$created} tagihan untuk anggota.");
    }

    /** Tandai lunas manual (bayar tunai) — Admin/Staff. */
    public function markPaid(Request $request, Desa $desa, DesaDues $dues): RedirectResponse
    {
        $this->authorize('manageFinance', $desa);
        abort_unless($dues->desa_id === $desa->id, 404);

        $this->finance->settle($dues, 'manual', $request->user());

        return back()->with('status', 'Iuran ditandai lunas & masuk kas desa.')->with('celebrate', true);
    }

    /** Anggota bayar online: siapkan order id baru + Snap token. */
    public function pay(Request $request, Desa $desa, DesaDues $dues): JsonResponse
    {
        abort_unless($dues->desa_id === $desa->id, 404);
        abort_unless($dues->user_id === $request->user()->id, 403);

        if ($dues->isPaid()) {
            return response()->json(['message' => 'Tagihan ini sudah lunas.'], 422);
        }

        // Order id baru tiap percobaan (hindari "order_id sudah digunakan").
        $dues->update([
            'midtrans_order_id' => 'DESADUES-' . $desa->id . '-' . $dues->id . '-' . Str::upper(Str::random(6)),
            'status' => DesaDuesStatus::Pending,
            'method' => 'online',
        ]);

        try {
            $token = $this->midtrans->createSnapTokenForDesaDues($dues);
        } catch (Throwable $e) {
            report($e);

            return response()->json(['message' => 'Gagal membuat transaksi Midtrans.'], 500);
        }

        return response()->json(['snap_token' => $token]);
    }

    /** Fallback tanpa webhook: cek status ke Midtrans lalu settle bila lunas. */
    public function sync(Request $request, Desa $desa, DesaDues $dues): RedirectResponse
    {
        abort_unless($dues->desa_id === $desa->id, 404);
        abort_unless(
            $dues->user_id === $request->user()->id || $request->user()->can('manageFinance', $desa),
            403,
        );

        if (! $dues->midtrans_order_id) {
            return back()->with('status', 'Belum ada pembayaran online untuk tagihan ini.');
        }

        try {
            $payload = $this->midtrans->fetchTransactionStatus($dues->midtrans_order_id);
        } catch (Throwable $e) {
            report($e);

            return back()->with('status', 'Belum ada transaksi di Midtrans. Selesaikan pembayaran dulu, lalu cek lagi.');
        }

        if ($this->midtrans->isPaidPayload($payload)) {
            $dues->update([
                'midtrans_status' => $payload['transaction_status'] ?? null,
                'midtrans_transaction_id' => $payload['transaction_id'] ?? null,
            ]);

            $this->finance->settle($dues, 'online', $dues->user);

            return back()->with('status', 'Pembayaran terkonfirmasi — iuran lunas!')->with('celebrate', true);
        }

        return back()->with('status', 'Pembayaran belum lunas / masih diproses.');
    }
}
