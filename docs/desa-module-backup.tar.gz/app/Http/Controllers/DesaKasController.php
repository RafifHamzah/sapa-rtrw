<?php

namespace App\Http\Controllers;

use App\Enums\DesaTransactionType;
use App\Models\Desa;
use Illuminate\Contracts\View\View;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;
use Illuminate\Validation\Rule;

class DesaKasController extends Controller
{
    /** Buku kas desa (transparan untuk semua anggota). */
    public function index(Request $request, Desa $desa): View
    {
        $this->authorize('view', $desa);

        $transactions = $desa->transactions()->with('recorder')->get();

        return view('desa.kas', [
            'desa' => $desa,
            'transactions' => $transactions,
            'balance' => $desa->kasBalance(),
            'income' => (int) $desa->transactions()->where('type', DesaTransactionType::Income->value)->sum('amount'),
            'expense' => (int) $desa->transactions()->where('type', DesaTransactionType::Expense->value)->sum('amount'),
            'canManage' => $request->user()->can('manageFinance', $desa),
        ]);
    }

    /** Catat transaksi kas — Admin/Staff. */
    public function store(Request $request, Desa $desa): RedirectResponse
    {
        $this->authorize('manageFinance', $desa);

        $data = $request->validate([
            'type' => ['required', Rule::enum(DesaTransactionType::class)],
            'amount' => ['required', 'integer', 'min:1'],
            'description' => ['required', 'string', 'max:255'],
            'transaction_date' => ['required', 'date'],
        ]);

        $desa->transactions()->create([
            'type' => $data['type'],
            'amount' => $data['amount'],
            'description' => $data['description'],
            'transaction_date' => $data['transaction_date'],
            'created_by' => $request->user()->id,
        ]);

        return back()->with('status', 'Transaksi kas dicatat.');
    }
}
